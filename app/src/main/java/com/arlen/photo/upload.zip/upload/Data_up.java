package com.arlen.photo.upload;
/**
 * Created by GOD on 2016/8/30.
 */

public class Data_up {
//    private static String a ="feiyangxiaomi";

    private static String SERVICE_URL = "http://10.148.83.157:8011/Service1.asmx";

    public static String getSERVICE_URL() {
        return SERVICE_URL;
    }

    public static void setA(String SERVICE_URL) {
        Data_up.SERVICE_URL = SERVICE_URL;
    }


}
